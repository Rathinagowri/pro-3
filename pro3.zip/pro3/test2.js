describe('binding', function() {
 it('bind', function() {
   browser.get('');
   expect(element(by.binding('greet')).getText()).toEqual("Helloworld");
 });

});